__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/6b0db230567c1e60.js",
  "static/chunks/turbopack-30b1893f34777787.js"
])
