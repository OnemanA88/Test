__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/6b0db230567c1e60.js",
  "static/chunks/turbopack-8f77657d62fe600d.js"
])
