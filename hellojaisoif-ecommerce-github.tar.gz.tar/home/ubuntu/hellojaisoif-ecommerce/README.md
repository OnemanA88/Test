This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Déploiement sur Vercel

Pour déployer cette application Next.js sur Vercel, suivez les étapes suivantes :

1.  **Téléchargez le dossier de construction :**
    Vous avez reçu un fichier compressé (`hellojaisoif-ecommerce-build.tar.gz`) contenant le dossier `.next` de l'application. Ce dossier contient la version optimisée et prête à être déployée de votre site.

2.  **Créez un nouveau projet Vercel :**
    -   Allez sur [Vercel](https://vercel.com/) et connectez-vous ou créez un compte.
    -   Cliquez sur "Add New..." puis "Project".
    -   Sélectionnez "Import Git Repository" si vous avez lié votre dépôt Git, ou "Deploy a Git Repository" si vous souhaitez importer un dossier local.

3.  **Importez le dossier de construction :**
    -   Si vous importez un dossier local, sélectionnez le dossier `.next` décompressé.
    -   Vercel détectera automatiquement qu'il s'agit d'une application Next.js.

4.  **Configurez les variables d'environnement :**
    -   Avant le déploiement, assurez-vous de configurer les variables d'environnement nécessaires (par exemple, clés API Supabase, Stripe, PayPal) dans les paramètres de votre projet Vercel.

5.  **Déployez :**
    -   Cliquez sur "Deploy". Vercel construira et déploiera votre application, vous fournissant une URL publique.

## Lancement en local

Pour lancer le projet en local, naviguez vers le dossier `hellojaisoif-ecommerce` et exécutez :

```bash
npm install
npm run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000) dans votre navigateur pour voir le résultat.
